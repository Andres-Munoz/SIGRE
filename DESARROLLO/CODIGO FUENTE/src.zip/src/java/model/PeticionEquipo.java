/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author fabian
 */
@Entity
@Table(name = "peticion_equipo", catalog = "SIGRE", schema = "")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "PeticionEquipo.findAll", query = "SELECT p FROM PeticionEquipo p")
    , @NamedQuery(name = "PeticionEquipo.findByIdPeticionEquipo", query = "SELECT p FROM PeticionEquipo p WHERE p.peticionEquipoPK.idPeticionEquipo = :idPeticionEquipo")
    , @NamedQuery(name = "PeticionEquipo.findByEstado", query = "SELECT p FROM PeticionEquipo p WHERE p.estado = :estado")
    , @NamedQuery(name = "PeticionEquipo.findByHoraInicio", query = "SELECT p FROM PeticionEquipo p WHERE p.horaInicio = :horaInicio")
    , @NamedQuery(name = "PeticionEquipo.findByHoraFin", query = "SELECT p FROM PeticionEquipo p WHERE p.horaFin = :horaFin")
    , @NamedQuery(name = "PeticionEquipo.findByFecha", query = "SELECT p FROM PeticionEquipo p WHERE p.fecha = :fecha")
    , @NamedQuery(name = "PeticionEquipo.findByEquipoIdEquipo", query = "SELECT p FROM PeticionEquipo p WHERE p.peticionEquipoPK.equipoIdEquipo = :equipoIdEquipo")
    , @NamedQuery(name = "PeticionEquipo.findByPersonaIdusuario", query = "SELECT p FROM PeticionEquipo p WHERE p.peticionEquipoPK.personaIdusuario = :personaIdusuario")})
public class PeticionEquipo implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected PeticionEquipoPK peticionEquipoPK;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 45)
    @Column(name = "estado")
    private String estado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "hora_inicio")
    @Temporal(TemporalType.TIME)
    private Date horaInicio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "hora_fin")
    @Temporal(TemporalType.TIME)
    private Date horaFin;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha")
    @Temporal(TemporalType.DATE)
    private Date fecha;
    @JoinColumn(name = "equipo_id_equipo", referencedColumnName = "id_equipo", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Equipo equipo;
    @JoinColumn(name = "persona_idusuario", referencedColumnName = "persona_idusuario", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Persona persona;

    public PeticionEquipo() {
    }

    public PeticionEquipo(PeticionEquipoPK peticionEquipoPK) {
        this.peticionEquipoPK = peticionEquipoPK;
    }

    public PeticionEquipo(PeticionEquipoPK peticionEquipoPK, String estado, Date horaInicio, Date horaFin, Date fecha) {
        this.peticionEquipoPK = peticionEquipoPK;
        this.estado = estado;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.fecha = fecha;
    }

    public PeticionEquipo(int idPeticionEquipo, int equipoIdEquipo, int personaIdusuario) {
        this.peticionEquipoPK = new PeticionEquipoPK(idPeticionEquipo, equipoIdEquipo, personaIdusuario);
    }

    public PeticionEquipoPK getPeticionEquipoPK() {
        return peticionEquipoPK;
    }

    public void setPeticionEquipoPK(PeticionEquipoPK peticionEquipoPK) {
        this.peticionEquipoPK = peticionEquipoPK;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public Date getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(Date horaInicio) {
        this.horaInicio = horaInicio;
    }

    public Date getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(Date horaFin) {
        this.horaFin = horaFin;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Equipo getEquipo() {
        return equipo;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public Persona getPersona() {
        return persona;
    }

    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (peticionEquipoPK != null ? peticionEquipoPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PeticionEquipo)) {
            return false;
        }
        PeticionEquipo other = (PeticionEquipo) object;
        if ((this.peticionEquipoPK == null && other.peticionEquipoPK != null) || (this.peticionEquipoPK != null && !this.peticionEquipoPK.equals(other.peticionEquipoPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.PeticionEquipo[ peticionEquipoPK=" + peticionEquipoPK + " ]";
    }
    
}
