/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author fabian
 */
@Embeddable
public class PeticionEquipoPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "id_peticion_equipo")
    private int idPeticionEquipo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "equipo_id_equipo")
    private int equipoIdEquipo;
    @Basic(optional = false)
    @NotNull
    @Column(name = "persona_idusuario")
    private int personaIdusuario;

    public PeticionEquipoPK() {
    }

    public PeticionEquipoPK(int idPeticionEquipo, int equipoIdEquipo, int personaIdusuario) {
        this.idPeticionEquipo = idPeticionEquipo;
        this.equipoIdEquipo = equipoIdEquipo;
        this.personaIdusuario = personaIdusuario;
    }

    public int getIdPeticionEquipo() {
        return idPeticionEquipo;
    }

    public void setIdPeticionEquipo(int idPeticionEquipo) {
        this.idPeticionEquipo = idPeticionEquipo;
    }

    public int getEquipoIdEquipo() {
        return equipoIdEquipo;
    }

    public void setEquipoIdEquipo(int equipoIdEquipo) {
        this.equipoIdEquipo = equipoIdEquipo;
    }

    public int getPersonaIdusuario() {
        return personaIdusuario;
    }

    public void setPersonaIdusuario(int personaIdusuario) {
        this.personaIdusuario = personaIdusuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idPeticionEquipo;
        hash += (int) equipoIdEquipo;
        hash += (int) personaIdusuario;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PeticionEquipoPK)) {
            return false;
        }
        PeticionEquipoPK other = (PeticionEquipoPK) object;
        if (this.idPeticionEquipo != other.idPeticionEquipo) {
            return false;
        }
        if (this.equipoIdEquipo != other.equipoIdEquipo) {
            return false;
        }
        if (this.personaIdusuario != other.personaIdusuario) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "model.PeticionEquipoPK[ idPeticionEquipo=" + idPeticionEquipo + ", equipoIdEquipo=" + equipoIdEquipo + ", personaIdusuario=" + personaIdusuario + " ]";
    }
    
}
